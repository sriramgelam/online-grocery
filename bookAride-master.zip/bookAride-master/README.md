# Book A Ride
A demo application for booking rides
There are two services service-1 and service-2.
By using first service you can enter ur ticket details and book the ride.
By using second service you can see the available rides.
